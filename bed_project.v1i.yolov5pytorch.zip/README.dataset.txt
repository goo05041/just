# bed_project > 2022-08-25 12:13pm
https://universe.roboflow.com/object-detection/bed_project

Provided by Roboflow
License: CC BY 4.0

